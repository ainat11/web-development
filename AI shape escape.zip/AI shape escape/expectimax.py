"""
Expectimax Algorithm for Enemy AI Decision Making
COMPLETELY REWRITTEN - Working properly
"""

import math
import random
import pygame
from settings import *

class ExpectimaxAgent:
    def __init__(self, enemy_id, grid_width, grid_height):
        self.enemy_id = enemy_id
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.total_evaluations = 0
        self.depth_limit = EXPECTIMAX_DEPTH
        
    def get_best_action(self, enemy_x, enemy_y, player_x, player_y, 
                        player_vx, player_vy, walls, wall_grid, depth=None):
        """
        Expectimax se best action select karo
        """
        if depth is None:
            depth = self.depth_limit
            
        actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']
        best_action = None
        best_value = -float('inf')
        
        for action in actions:
            # Simulate action
            new_x, new_y = enemy_x, enemy_y
            if action == 'UP':
                new_y -= 40
            elif action == 'DOWN':
                new_y += 40
            elif action == 'LEFT':
                new_x -= 40
            elif action == 'RIGHT':
                new_x += 40
                
            # Check wall collision
            hit_wall = False
            test_rect = pygame.Rect(new_x, new_y, PLAYER_SIZE, PLAYER_SIZE)
            for wall in walls:
                if test_rect.colliderect(wall):
                    hit_wall = True
                    break
                    
            if hit_wall:
                value = -50  # Heavy penalty for wall hit
            else:
                # Evaluate using expectimax
                value = self.expectimax(
                    new_x, new_y, player_x, player_y,
                    player_vx, player_vy, walls, wall_grid,
                    depth - 1, is_max_node=False
                )
                
                # Add distance-based reward
                dx = player_x - new_x
                dy = player_y - new_y
                distance = math.hypot(dx, dy)
                value += 500 / (distance + 50)  # Closer = higher value
                
            if value > best_value:
                best_value = value
                best_action = action
                
        self.total_evaluations += 1
        return best_action, best_value
        
    def expectimax(self, enemy_x, enemy_y, player_x, player_y,
                   player_vx, player_vy, walls, wall_grid,
                   depth, is_max_node):
        """
        Expectimax recursive evaluation
        """
        if depth == 0:
            # Base case: evaluate current state
            dx = player_x - enemy_x
            dy = player_y - enemy_y
            distance = math.hypot(dx, dy)
            # Higher value when closer to player
            return 500 / (distance + 50)
            
        if is_max_node:
            # MAX node - enemy chooses best action
            best_value = -float('inf')
            actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']
            
            for action in actions:
                new_x, new_y = enemy_x, enemy_y
                if action == 'UP':
                    new_y -= 40
                elif action == 'DOWN':
                    new_y += 40
                elif action == 'LEFT':
                    new_x -= 40
                elif action == 'RIGHT':
                    new_x += 40
                    
                # Check wall collision
                hit_wall = False
                test_rect = pygame.Rect(new_x, new_y, PLAYER_SIZE, PLAYER_SIZE)
                for wall in walls:
                    if test_rect.colliderect(wall):
                        hit_wall = True
                        break
                        
                if hit_wall:
                    value = -50
                else:
                    value = self.expectimax(
                        new_x, new_y, player_x, player_y,
                        player_vx, player_vy, walls, wall_grid,
                        depth - 1, is_max_node=False
                    )
                    
                best_value = max(best_value, value)
                
            return best_value
            
        else:
            # CHANCE node - player movement prediction (expected value)
            total_value = 0
            # Possible player movements with probabilities
            possible_moves = [
                (0, 0, 0.3),      # Stay
                (-20, 0, 0.175),  # Left
                (20, 0, 0.175),   # Right
                (0, -20, 0.175),  # Up
                (0, 20, 0.175)    # Down
            ]
            
            for dx, dy, prob in possible_moves:
                new_px = player_x + dx
                new_py = player_y + dy
                
                # Keep player in bounds
                new_px = max(0, min(self.grid_width * CELL_SIZE - PLAYER_SIZE, new_px))
                new_py = max(0, min(self.grid_height * CELL_SIZE - PLAYER_SIZE, new_py))
                
                value = self.expectimax(
                    enemy_x, enemy_y, new_px, new_py,
                    player_vx, player_vy, walls, wall_grid,
                    depth - 1, is_max_node=True
                )
                
                total_value += prob * value
                
            return total_value
            
    def get_direct_action(self, enemy_x, enemy_y, player_x, player_y, walls):
        """
        Fallback direct movement (always works)
        """
        dx = player_x - enemy_x
        dy = player_y - enemy_y
        
        if abs(dx) > abs(dy):
            return 'RIGHT' if dx > 0 else 'LEFT'
        else:
            return 'DOWN' if dy > 0 else 'UP'
            
    def get_stats(self):
        return {
            'total_evaluations': self.total_evaluations,
            'depth_limit': self.depth_limit
        }