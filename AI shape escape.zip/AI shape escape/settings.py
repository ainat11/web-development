"""
Game settings and configuration constants
"""

import pygame

# Screen dimensions
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 650
CELL_SIZE = 40

# FPS
FPS = 60

# Color Palette
BG_PRIMARY = (18, 18, 24)
BG_SECONDARY = (28, 28, 35)
BG_PANEL = (22, 22, 28)
SURFACE = (32, 32, 40)
BORDER = (50, 50, 65)

# Text colors
TEXT_PRIMARY = (230, 230, 240)
TEXT_SECONDARY = (160, 160, 180)
TEXT_MUTED = (100, 100, 120)
TEXT_DARK = (60, 60, 75)

# Accent colors
ACCENT_BLUE = (64, 128, 200)
ACCENT_GREEN = (52, 168, 108)
ACCENT_RED = (200, 70, 70)
ACCENT_ORANGE = (220, 140, 60)
ACCENT_PURPLE = (140, 90, 190)
ACCENT_CYAN = (60, 140, 160)
ACCENT_YELLOW = (210, 180, 60)

# Enemy colors
ENEMY_RED = (200, 70, 70)

# Health bar colors
HEALTH_HIGH = (52, 168, 108)
HEALTH_MED = (210, 180, 60)
HEALTH_LOW = (200, 70, 70)

# Game settings
PLAYER_SIZE = 34
PLAYER_START_X = 100
PLAYER_START_Y = 100
PLAYER_BASE_SPEED = 5
PLAYER_MAX_HEALTH = 100
PLAYER_START_HEALTH = 100

# Dash settings
DASH_SPEED = 15
DASH_DURATION = 5
DASH_COOLDOWN_MAX = 180

# Health reward system
HEALTH_INCREASE_INTERVAL = 100
HEALTH_GAIN_AMOUNT = 2

# Level system
LEVEL_SCORE_REQUIREMENTS = {
    1: 0,
    2: 800,
    3: 2000
}

LEVEL_CONFIGS = {
    1: {
        "name": "BEGINNER",
        "difficulty_label": "Beginner",
        "enemy_speed_multiplier": 0.7,
        "base_enemy_count": 2,
        "enemy_types": ["chaser", "expectimax"],
        "player_speed": 5,
        "color": ACCENT_GREEN,
        "description": "Training Phase"
    },
    2: {
        "name": "ADVANCED",
        "difficulty_label": "Advanced",
        "enemy_speed_multiplier": 1.0,
        "base_enemy_count": 3,
        "enemy_types": ["chaser", "smart", "expectimax"],
        "player_speed": 5,
        "color": ACCENT_BLUE,
        "description": "Challenge Begins"
    },
    3: {
        "name": "EXPERT",
        "difficulty_label": "Expert",
        "enemy_speed_multiplier": 1.3,
        "base_enemy_count": 4,
        "enemy_types": ["chaser", "smart", "ambusher", "expectimax"],
        "player_speed": 5,
        "color": ACCENT_RED,
        "description": "Maximum Difficulty"
    }
}

# Enemy base speeds
ENEMY_BASE_SPEEDS = {
    "chaser": 2.2,
    "fast": 4.0,
    "smart": 2.5,
    "ambusher": 2.0,
    "tank": 1.2,
    "expectimax": 2.5  # Increased speed for expectimax
}

# Expectimax settings
EXPECTIMAX_DEPTH = 2
EXPECTIMAX_CHASE_WEIGHT = 5.0
EXPECTIMAX_AVOID_WEIGHT = 3.0

# Pathfinding settings
PATH_UPDATE_DELAY = 6
PREDICTION_TIME = 1.5

# Powerup settings
POWERUP_SPAWN_CHANCE = 700
POWERUP_DURATION = 300

# Game states
MENU = 0
PLAYING = 1
GAME_OVER = 2
LEVEL_TRANSITION = 3

# Font sizes
FONT_TITLE = 72
FONT_LARGE = 48
FONT_MEDIUM = 32
FONT_SMALL = 20
FONT_TINY = 14