# Shape Escape - Expectimax AI Game

## Overview
Shape Escape is a professional AI-based survival game where you control a shape and must escape from intelligent enemies powered by the **Expectimax Algorithm**. The enemies predict your future movements and make strategic decisions to intercept you.

## Features
- 🧠 **Expectimax AI**: Enemies predict player movements and choose optimal actions
- 🎮 **Smooth Gameplay**: 60 FPS with responsive controls
- 💥 **Powerups**: Shield, Speed Boost, and Health Recovery
- 🎨 **Cyber-Neon Theme**: Professional visual effects and animations
- 📈 **Dynamic Difficulty**: Increasing levels with more obstacles and enemies
- ✨ **Particle System**: Visual effects for damage, powerups, and more

## Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Setup Instructions for VS Code

1. **Clone or download the project files**

2. **Open the project in VS Code**