"""
Enemy AI with Expectimax Decision Making
FIXED: Expectimax enemy now properly follows player
"""

import pygame
import math
import random
from settings import *
from expectimax import ExpectimaxAgent

class Enemy:
    # AI States
    STATE_ATTACK = 0
    STATE_CHASE = 1
    STATE_AMBUSH = 2
    STATE_SEARCH = 3
    STATE_EXPECTIMAX = 4
    
    def __init__(self, x, y, enemy_type, level, grid_width, grid_height, enemy_id=0):
        self.x = x
        self.y = y
        self.size = 35
        self.type = enemy_type
        self.health = 100
        self.max_health = 100
        self.base_speed = self.get_base_speed()
        
        # Movement system
        self.velocity_x = 0
        self.velocity_y = 0
        self.smoothness = 0.85
        
        # AI State variables
        self.state = self.STATE_CHASE
        self.last_known_player_x = x
        self.last_known_player_y = y
        self.search_radius = 0
        self.search_angle = 0
        self.prediction_time = PREDICTION_TIME
        
        # Grid dimensions
        self.grid_width = grid_width
        self.grid_height = grid_height
        
        # Expectimax agent - FIXED
        self.expectimax_agent = None
        if enemy_type == "expectimax":
            self.expectimax_agent = ExpectimaxAgent(enemy_id, grid_width, grid_height)
            self.state = self.STATE_EXPECTIMAX
            self.last_action = None
            self.action_timer = 0
            self.action_delay = 5  # Faster updates for better responsiveness
            
        # Smart enemy special attributes
        if enemy_type == "smart":
            self.smart_prediction_weight = 1.5
            
        # Apply level-based speed multiplier
        self.apply_level_speed(level)
        self.speed = self.base_speed
        
    def get_base_speed(self):
        return ENEMY_BASE_SPEEDS.get(self.type, 2.5)
        
    def apply_level_speed(self, level):
        if level in LEVEL_CONFIGS:
            multiplier = LEVEL_CONFIGS[level]["enemy_speed_multiplier"]
            self.base_speed *= multiplier
            
    def get_color(self):
        return ACCENT_RED
        
    def get_health_bar_color(self):
        if self.health > 70:
            return HEALTH_HIGH
        elif self.health > 30:
            return HEALTH_MED
        else:
            return HEALTH_LOW
            
    def get_state_text(self):
        if self.type == "expectimax":
            return "EXPECTIMAX"
        elif self.type == "chaser":
            return "CHASE"
        elif self.type == "smart":
            return "SMART"
        elif self.type == "ambusher":
            return "AMBUSH"
        elif self.type == "tank":
            return "TANK"
        else:
            return "ENEMY"
            
    def update_state(self, player_x, player_y):
        dx = player_x - self.x
        dy = player_y - self.y
        distance = math.hypot(dx, dy)
        
        if self.type == "expectimax":
            return
            
        self.last_known_player_x = player_x
        self.last_known_player_y = player_y
        
        if self.type == "smart":
            if distance < 120:
                self.state = self.STATE_ATTACK
            elif distance < 350:
                self.state = self.STATE_AMBUSH
            else:
                self.state = self.STATE_CHASE
        elif self.type == "ambusher":
            if distance < 150:
                self.state = self.STATE_ATTACK
            elif distance < 350:
                self.state = self.STATE_AMBUSH
            else:
                self.state = self.STATE_CHASE
        else:
            if distance < 100:
                self.state = self.STATE_ATTACK
            else:
                self.state = self.STATE_CHASE
                
    def calculate_ambush_position(self, player_x, player_y, player_vx, player_vy):
        if abs(player_vx) < 0.5 and abs(player_vy) < 0.5:
            return (player_x, player_y)
        
        prediction_time = self.prediction_time * 1.3 if self.type == "smart" else self.prediction_time
        predicted_x = player_x + (player_vx * prediction_time)
        predicted_y = player_y + (player_vy * prediction_time)
        
        return (predicted_x, predicted_y)
        
    def smooth_move(self, target_x, target_y, walls, slow_motion):
        """Smooth movement towards target"""
        current_speed = self.speed
        if slow_motion:
            current_speed *= 0.5
            
        # Calculate direction to target
        dx = target_x - (self.x + self.size // 2)
        dy = target_y - (self.y + self.size // 2)
        distance = math.hypot(dx, dy)
        
        if distance > 0:
            # Move towards target
            move_x = (dx / distance) * min(current_speed, distance)
            move_y = (dy / distance) * min(current_speed, distance)
        else:
            return
            
        # Apply movement with collision
        self.apply_movement(move_x, move_y, walls)
        
    def apply_movement(self, move_x, move_y, walls):
        """Apply movement with proper collision detection"""
        old_x, old_y = self.x, self.y
        
        # Move X
        self.x += move_x
        enemy_rect = pygame.Rect(self.x, self.y, self.size, self.size)
        
        for wall in walls:
            if enemy_rect.colliderect(wall):
                if move_x > 0:
                    self.x = wall.left - self.size
                elif move_x < 0:
                    self.x = wall.right
                break
                
        # Move Y
        self.y += move_y
        enemy_rect = pygame.Rect(self.x, self.y, self.size, self.size)
        
        for wall in walls:
            if enemy_rect.colliderect(wall):
                if move_y > 0:
                    self.y = wall.top - self.size
                elif move_y < 0:
                    self.y = wall.bottom
                break
                
        # Bounds checking
        max_x = self.grid_width * CELL_SIZE - self.size
        max_y = self.grid_height * CELL_SIZE - self.size
        self.x = max(0, min(max_x, self.x))
        self.y = max(0, min(max_y, self.y))
        
    def update_expectimax(self, player_x, player_y, player_vx, player_vy, walls, wall_grid, slow_motion):
        """EXPECTIMAX AI - Now properly chases player"""
        if not self.expectimax_agent:
            return
            
        # Update action periodically
        self.action_timer += 1
        if self.action_timer >= self.action_delay:
            self.action_timer = 0
            
            # Get best action from expectimax
            best_action, value = self.expectimax_agent.get_best_action(
                self.x, self.y, player_x, player_y,
                player_vx, player_vy, walls, wall_grid
            )
            
            # If no valid action from expectimax, use direct movement
            if best_action is None:
                best_action = self.expectimax_agent.get_direct_action(
                    self.x, self.y, player_x, player_y, walls
                )
                
            self.last_action = best_action
            
        # Apply the chosen action
        if self.last_action:
            move_x, move_y = 0, 0
            current_speed = self.speed * (0.7 if slow_motion else 1.0)
            
            if self.last_action == 'UP':
                move_y = -current_speed
            elif self.last_action == 'DOWN':
                move_y = current_speed
            elif self.last_action == 'LEFT':
                move_x = -current_speed
            elif self.last_action == 'RIGHT':
                move_x = current_speed
                
            # Apply movement with collision
            self.apply_movement(move_x, move_y, walls)
            
    def update_chase(self, player_x, player_y, player_vx, player_vy, walls, slow_motion):
        """Traditional chase AI"""
        self.update_state(player_x, player_y)
        
        # Determine target based on state
        if self.state == self.STATE_ATTACK:
            target_x, target_y = player_x, player_y
            
        elif self.state == self.STATE_AMBUSH:
            target_x, target_y = self.calculate_ambush_position(
                player_x, player_y, player_vx, player_vy
            )
            
        elif self.state == self.STATE_SEARCH:
            self.search_angle += 0.1
            self.search_radius += 0.3
            if self.search_radius > 150:
                self.search_radius = 50
            target_x = self.last_known_player_x + math.cos(self.search_angle) * self.search_radius
            target_y = self.last_known_player_y + math.sin(self.search_angle) * self.search_radius
            
        else:  # STATE_CHASE
            prediction = self.prediction_time * 1.2 if self.type == "smart" else self.prediction_time
            target_x = player_x + (player_vx * prediction)
            target_y = player_y + (player_vy * prediction)
            
        # Move towards target
        self.smooth_move(target_x, target_y, walls, slow_motion)
        
    def update_ai(self, player_x, player_y, player_vx, player_vy, walls, slow_motion, wall_grid):
        """Main AI update"""
        
        if self.type == "expectimax" and self.expectimax_agent:
            self.update_expectimax(player_x, player_y, player_vx, player_vy, walls, wall_grid, slow_motion)
        else:
            self.update_chase(player_x, player_y, player_vx, player_vy, walls, slow_motion)
        
    def get_expectimax_stats(self):
        if self.expectimax_agent:
            return self.expectimax_agent.get_stats()
        return None