"""
Map and wall generation
"""

import pygame
import random
from settings import *

class WallManager:
    def __init__(self):
        self.walls = []
        self.wall_grid = set()
        self.cell_size = CELL_SIZE
        
    def init_walls(self):
        """Initialize default wall positions"""
        self.walls = []
        wall_positions = [
            (240, 120), (240, 160), (240, 200),
            (520, 300), (560, 300), (600, 300),
            (760, 120), (760, 160),
            (400, 500), (440, 500),
            (120, 420), (160, 420), (200, 420),
            (850, 450), (850, 490), (850, 530)
        ]
        
        for pos in wall_positions:
            self.walls.append(pygame.Rect(pos[0], pos[1], CELL_SIZE, CELL_SIZE))
        self.rebuild_grid()
        
    def rebuild_grid(self):
        """Rebuild the wall grid for pathfinding"""
        self.wall_grid = set()
        for wall in self.walls:
            grid_x = wall.x // CELL_SIZE
            grid_y = wall.y // CELL_SIZE
            self.wall_grid.add((grid_x, grid_y))
            
    def generate_maze(self, level, width, height):
        """Generate maze based on level"""
        new_walls = []
        grid_width = width // CELL_SIZE
        grid_height = height // CELL_SIZE
        
        if level == 1:
            self.init_walls()
            new_walls = self.walls
            
        elif level == 2:
            for i in range(30):
                x = random.randint(2, grid_width - 3) * CELL_SIZE
                y = random.randint(2, grid_height - 3) * CELL_SIZE
                new_walls.append(pygame.Rect(x, y, CELL_SIZE, CELL_SIZE))
                
        elif level >= 3:
            for x in range(CELL_SIZE * 2, width - CELL_SIZE * 2, CELL_SIZE * 3):
                for y in range(CELL_SIZE, height - CELL_SIZE, CELL_SIZE):
                    if random.random() > 0.4:
                        new_walls.append(pygame.Rect(x, y, CELL_SIZE, CELL_SIZE))
                        
            for y in range(CELL_SIZE * 2, height - CELL_SIZE * 2, CELL_SIZE * 3):
                for x in range(CELL_SIZE, width - CELL_SIZE, CELL_SIZE):
                    if random.random() > 0.4:
                        new_walls.append(pygame.Rect(x, y, CELL_SIZE, CELL_SIZE))
                        
            for i in range(50):
                x = random.randint(1, grid_width - 2) * CELL_SIZE
                y = random.randint(1, grid_height - 2) * CELL_SIZE
                new_walls.append(pygame.Rect(x, y, CELL_SIZE, CELL_SIZE))
        
        self.walls = new_walls
        self.rebuild_grid()
        return self.walls
        
    def is_wall_at(self, x, y):
        return (x, y) in self.wall_grid
        
    def is_collision(self, rect):
        for wall in self.walls:
            if rect.colliderect(wall):
                return True
        return False
        
    def get_nearby_walls(self, x, y, radius=2):
        """Get walls within radius for expectimax evaluation"""
        nearby = []
        grid_x = int(x // CELL_SIZE)
        grid_y = int(y // CELL_SIZE)
        
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                check_x = grid_x + dx
                check_y = grid_y + dy
                if (check_x, check_y) in self.wall_grid:
                    nearby.append((check_x, check_y))
        return nearby
        
    def draw(self, screen):
        for wall in self.walls:
            # Solid fill
            pygame.draw.rect(screen, SURFACE, wall, border_radius=8)
            # Border only
            pygame.draw.rect(screen, BORDER, wall, 1, border_radius=8)
            
    def get_walls(self):
        return self.walls