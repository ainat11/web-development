"""
Shape Escape - Game with Expectimax AI
COMPLETELY REWRITTEN - Smooth player movement, no wall sticking
"""

import pygame
import sys
import random
import math

from settings import *
from map import WallManager
from enemy_ai import Enemy

class ShapeEscapeGame:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
        pygame.display.set_caption("Shape Escape - Expectimax AI")
        self.clock = pygame.time.Clock()
        self.running = True
        self.game_state = MENU
        
        # Game world dimensions
        self.width = SCREEN_WIDTH
        self.height = SCREEN_HEIGHT
        self.grid_width = max(1, self.width // CELL_SIZE)
        self.grid_height = max(1, self.height // CELL_SIZE)
        
        # Player movement system - SMOOTH
        self.player_x = PLAYER_START_X
        self.player_y = PLAYER_START_Y
        self.player_size = PLAYER_SIZE
        self.player_health = PLAYER_START_HEALTH
        self.player_max_health = PLAYER_MAX_HEALTH
        self.player_speed = PLAYER_BASE_SPEED
        self.player_velocity_x = 0
        self.player_velocity_y = 0
        self.player_smoothness = 0.85  # Movement smoothing
        
        # Initialize components
        self.wall_manager = WallManager()
        self.wall_manager.init_walls()
        
        # Score system
        self.score = 0
        self.mission_score = 0
        self.current_level = 1
        self.level_transition_timer = 0
        self.level_transition_message = ""
        
        # Dash system
        self.dash_cooldown = 0
        self.dash_duration = 0
        self.dash_available = True
        
        # Powerups
        self.shield_active = False
        self.shield_timer = 0
        self.speed_boost = False
        self.speed_timer = 0
        self.slow_motion_active = False
        self.slow_motion_timer = 0
        
        # Health reward system
        self.last_health_milestone = 0
        self.health_gain_flash_timer = 0
        
        # Effects
        self.health_gain_particles = []
        self.floating_texts = []
        self.powerups = []
        
        # Enemies
        self.enemies = []
        self.next_enemy_id = 0
        
        # Missions
        self.missions = {
            "survive_time": {"completed": False, "current": 0, "target": 60, "desc": "Survive 60s"},
            "collect_powerups": {"completed": False, "current": 0, "target": 5, "desc": "Collect 5 items"},
            "kill_enemies": {"completed": False, "current": 0, "target": 10, "desc": "Kill 10 enemies"}
        }
        self.powerups_collected = 0
        self.enemies_killed = 0
        self.seconds_survived = 0
        
        # Background particles
        self.particles = []
        self.init_particles()
        
        # Fonts
        self.font_title = pygame.font.Font(None, FONT_TITLE)
        self.font_large = pygame.font.Font(None, FONT_LARGE)
        self.font_medium = pygame.font.Font(None, FONT_MEDIUM)
        self.font_small = pygame.font.Font(None, FONT_SMALL)
        self.font_tiny = pygame.font.Font(None, FONT_TINY)
        
        self.init_sound()
        
    def init_sound(self):
        try:
            pygame.mixer.init()
        except:
            pass
            
    def init_particles(self):
        self.particles = []
        for i in range(50):
            self.particles.append({
                "x": random.randint(0, self.width),
                "y": random.randint(0, self.height),
                "size": random.randint(1, 2),
                "speed": random.uniform(0.3, 0.8),
            })
            
    def update_grid_dimensions(self):
        self.grid_width = max(1, self.width // CELL_SIZE)
        self.grid_height = max(1, self.height // CELL_SIZE)
        
    def spawn_enemies_for_level(self):
        self.enemies.clear()
        
        if self.current_level in LEVEL_CONFIGS:
            config = LEVEL_CONFIGS[self.current_level]
            num_enemies = config["base_enemy_count"]
            enemy_type_list = config["enemy_types"]
        else:
            num_enemies = 2
            enemy_type_list = ["chaser", "expectimax"]
        
        for i in range(num_enemies):
            if i < len(enemy_type_list):
                enemy_type = enemy_type_list[i]
            else:
                enemy_type = random.choice(enemy_type_list)
            
            margin = 80
            x = random.randint(margin, self.width - margin - PLAYER_SIZE)
            y = random.randint(margin, self.height - margin - PLAYER_SIZE)
            attempts = 0
            while abs(x - self.player_x) < 100 and abs(y - self.player_y) < 100 and attempts < 20:
                x = random.randint(margin, self.width - margin - PLAYER_SIZE)
                y = random.randint(margin, self.height - margin - PLAYER_SIZE)
                attempts += 1
                
            enemy = Enemy(x, y, enemy_type, self.current_level, 
                         self.grid_width, self.grid_height, self.next_enemy_id)
            self.enemies.append(enemy)
            self.next_enemy_id += 1
            
    def check_level_up(self):
        target_level = 1
        for level_num, required_score in LEVEL_SCORE_REQUIREMENTS.items():
            if int(self.score) >= required_score:
                target_level = level_num
        
        if target_level > 3:
            target_level = 3
        
        if target_level != self.current_level:
            self.current_level = target_level
            
            self.level_transition_message = f"LEVEL {self.current_level} - {LEVEL_CONFIGS[self.current_level]['name']}"
            self.game_state = LEVEL_TRANSITION
            self.level_transition_timer = 90
            
            self.player_speed = LEVEL_CONFIGS[self.current_level]["player_speed"]
            self.player_health = min(self.player_max_health, self.player_health + 20)
            self.create_floating_text("LEVEL UP!", self.width//2, self.height//2, ACCENT_GREEN)
            
            self.spawn_enemies_for_level()
            
    def check_score_health_reward(self):
        current_milestone = int(self.score // HEALTH_INCREASE_INTERVAL)
        
        if current_milestone > self.last_health_milestone:
            milestones_gained = current_milestone - self.last_health_milestone
            health_gained = milestones_gained * HEALTH_GAIN_AMOUNT
            
            old_health = self.player_health
            self.player_health = min(self.player_max_health, self.player_health + health_gained)
            actual_gain = self.player_health - old_health
            
            if actual_gain > 0:
                self.health_gain_flash_timer = 10
                self.add_health_gain_particles(self.player_x + self.player_size // 2, 
                                               self.player_y + self.player_size // 2)
                self.create_floating_text(f"+{actual_gain} HP", 
                                         self.player_x + self.player_size // 2, 
                                         self.player_y - 20, ACCENT_GREEN)
            
            self.last_health_milestone = current_milestone
            
    def add_health_gain_particles(self, x, y):
        for i in range(12):
            self.health_gain_particles.append({
                "x": x + random.randint(-20, 20),
                "y": y + random.randint(-20, 20),
                "vx": random.uniform(-2, 2),
                "vy": random.uniform(-4, -1),
                "life": 25,
                "color": ACCENT_GREEN
            })
            
    def create_floating_text(self, text, x, y, color):
        self.floating_texts.append({
            "text": text,
            "x": x,
            "y": y,
            "life": 40,
            "color": color,
            "velocity_y": -1.2
        })
        
    def update_floating_texts(self):
        for ft in self.floating_texts[:]:
            ft["y"] += ft["velocity_y"]
            ft["life"] -= 1
            if ft["life"] <= 0:
                self.floating_texts.remove(ft)
            else:
                text = self.font_tiny.render(ft["text"], True, ft["color"])
                self.screen.blit(text, (int(ft["x"]), int(ft["y"])))
                
    def update_health_particles(self):
        for p in self.health_gain_particles[:]:
            p["x"] += p["vx"]
            p["y"] += p["vy"]
            p["vy"] += 0.15
            p["life"] -= 1
            if p["life"] <= 0:
                self.health_gain_particles.remove(p)
            else:
                alpha = p["life"] / 25
                color = (int(p["color"][0] * alpha), 
                        int(p["color"][1] * alpha), 
                        int(p["color"][2] * alpha))
                pygame.draw.circle(self.screen, color, (int(p["x"]), int(p["y"])), 2)
                
    def draw_text(self, text, font, color, x, y, center=True):
        surface = font.render(text, True, color)
        if center:
            rect = surface.get_rect(center=(x, y))
            self.screen.blit(surface, rect)
        else:
            self.screen.blit(surface, (x, y))
            
    def draw_panel(self, rect, color=None, border_radius=12):
        if color is None:
            color = BG_PANEL
        pygame.draw.rect(self.screen, color, rect, border_radius=border_radius)
        pygame.draw.rect(self.screen, BORDER, rect, 1, border_radius=border_radius)
        
    def draw_background_particles(self):
        for p in self.particles:
            p["y"] += p["speed"]
            if p["y"] > self.height:
                p["y"] = 0
                p["x"] = random.randint(0, self.width)
            alpha_val = 40
            pygame.draw.circle(self.screen, (*TEXT_MUTED, alpha_val), 
                             (int(p["x"]), int(p["y"])), p["size"])
            
    def draw_grid(self):
        for x in range(0, self.width, 40):
            pygame.draw.line(self.screen, (30, 30, 38), (x, 0), (x, self.height), 1)
        for y in range(0, self.height, 40):
            pygame.draw.line(self.screen, (30, 30, 38), (0, y), (self.width, y), 1)
            
    def draw_button(self, text, x, y, w, h, color):
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        rect = pygame.Rect(x, y, w, h)
        hovered = rect.collidepoint(mouse)
        
        if hovered:
            pygame.draw.rect(self.screen, (*color[:2], min(color[2]+30, 255)), rect, border_radius=12)
            pygame.draw.rect(self.screen, TEXT_PRIMARY, rect, 2, border_radius=12)
        else:
            pygame.draw.rect(self.screen, color, rect, border_radius=12)
            pygame.draw.rect(self.screen, BORDER, rect, 1, border_radius=12)
            
        self.draw_text(text, self.font_medium, TEXT_PRIMARY, x + w//2, y + h//2)
        
        if hovered and click[0]:
            return True
        return False
        
    def reset_game(self):
        self.player_x = PLAYER_START_X
        self.player_y = PLAYER_START_Y
        self.player_health = PLAYER_START_HEALTH
        self.score = 0
        self.mission_score = 0
        self.current_level = 1
        self.player_speed = PLAYER_BASE_SPEED
        self.player_velocity_x = 0
        self.player_velocity_y = 0
        
        self.dash_cooldown = 0
        self.dash_duration = 0
        self.shield_active = False
        self.speed_boost = False
        self.slow_motion_active = False
        self.slow_motion_timer = 0
        
        self.last_health_milestone = 0
        self.health_gain_flash_timer = 0
        self.health_gain_particles.clear()
        self.floating_texts.clear()
        self.powerups.clear()
        
        self.powerups_collected = 0
        self.enemies_killed = 0
        
        for mission in self.missions.values():
            mission["completed"] = False
            mission["current"] = 0
            
        self.update_grid_dimensions()
        self.wall_manager.generate_maze(1, self.width, self.height)
        self.spawn_enemies_for_level()
        
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                
            elif event.type == pygame.VIDEORESIZE:
                self.width, self.height = event.w, event.h
                self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
                self.update_grid_dimensions()
                
                if self.game_state == PLAYING:
                    self.wall_manager.generate_maze(self.current_level, self.width, self.height)
                    
                self.player_x = min(max(self.player_x, 0), self.width - self.player_size)
                self.player_y = min(max(self.player_y, 0), self.height - self.player_size)
                self.init_particles()
                
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.game_state == PLAYING:
                        self.game_state = MENU
                    else:
                        self.running = False
                        
    def handle_player_input(self):
        keys = pygame.key.get_pressed()
        
        # Dash
        if keys[pygame.K_SPACE] and self.dash_cooldown == 0 and self.dash_duration == 0:
            dash_dir_x, dash_dir_y = 0, 0
            if keys[pygame.K_LEFT]: dash_dir_x = -1
            if keys[pygame.K_RIGHT]: dash_dir_x = 1
            if keys[pygame.K_UP]: dash_dir_y = -1
            if keys[pygame.K_DOWN]: dash_dir_y = 1
            
            if dash_dir_x == 0 and dash_dir_y == 0:
                dash_dir_x = 1
                
            if dash_dir_x != 0 and dash_dir_y != 0:
                dash_dir_x *= 0.707
                dash_dir_y *= 0.707
                
            # Instant dash
            self.player_x += dash_dir_x * DASH_SPEED
            self.player_y += dash_dir_y * DASH_SPEED
            
            # Keep in bounds
            self.player_x = max(0, min(self.width - self.player_size, self.player_x))
            self.player_y = max(0, min(self.height - self.player_size, self.player_y))
            
            # Check wall collision after dash
            player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)
            if self.wall_manager.is_collision(player_rect):
                self.player_x -= dash_dir_x * DASH_SPEED
                self.player_y -= dash_dir_y * DASH_SPEED
                    
            self.dash_duration = DASH_DURATION
            self.dash_cooldown = DASH_COOLDOWN_MAX
            
        # Update cooldowns
        if self.dash_cooldown > 0:
            self.dash_cooldown -= 1
        if self.dash_duration > 0:
            self.dash_duration -= 1
        if self.slow_motion_timer > 0:
            self.slow_motion_timer -= 1
            if self.slow_motion_timer <= 0:
                self.slow_motion_active = False
        if self.speed_timer > 0:
            self.speed_timer -= 1
            if self.speed_timer <= 0:
                self.speed_boost = False
        if self.shield_timer > 0:
            self.shield_timer -= 1
            if self.shield_timer <= 0:
                self.shield_active = False
                
        current_speed = self.player_speed
        if self.speed_boost:
            current_speed = 8
            
        # Get input direction
        move_x, move_y = 0, 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            move_x -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            move_x += 1
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            move_y -= 1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            move_y += 1
            
        # Normalize diagonal movement
        if move_x != 0 and move_y != 0:
            move_x *= 0.707
            move_y *= 0.707
            
        # Calculate desired velocity
        desired_vx = move_x * current_speed
        desired_vy = move_y * current_speed
        
        # Smooth velocity transition
        self.player_velocity_x = self.player_velocity_x * self.player_smoothness + desired_vx * (1 - self.player_smoothness)
        self.player_velocity_y = self.player_velocity_y * self.player_smoothness + desired_vy * (1 - self.player_smoothness)
        
        # Apply movement with collision
        self.apply_player_movement()
        
    def apply_player_movement(self):
        """Smooth player movement with collision detection"""
        old_x, old_y = self.player_x, self.player_y
        
        # Move X
        self.player_x += self.player_velocity_x
        player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)
        
        if self.wall_manager.is_collision(player_rect):
            self.player_x = old_x
            self.player_velocity_x = 0
            
        # Move Y
        self.player_y += self.player_velocity_y
        player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)
        
        if self.wall_manager.is_collision(player_rect):
            self.player_y = old_y
            self.player_velocity_y = 0
            
        # Screen bounds
        self.player_x = max(0, min(self.width - self.player_size, self.player_x))
        self.player_y = max(0, min(self.height - self.player_size, self.player_y))
        
    def update_powerups(self):
        player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)
        
        if random.randint(1, POWERUP_SPAWN_CHANCE) == 1:
            margin = 50
            self.powerups.append({
                "x": random.randint(margin, self.width - margin),
                "y": random.randint(margin, self.height - margin),
                "type": random.choice(["speed", "shield", "slowmotion"])
            })
            
        for power in self.powerups[:]:
            colors = {"speed": ACCENT_YELLOW, "shield": ACCENT_PURPLE, "slowmotion": ACCENT_CYAN}
            color = colors.get(power["type"], TEXT_SECONDARY)
            
            pygame.draw.circle(self.screen, SURFACE, (power["x"], power["y"]), 16)
            pygame.draw.circle(self.screen, color, (power["x"], power["y"]), 14)
            pygame.draw.circle(self.screen, color, (power["x"], power["y"]), 14, 1)
            
            power_rect = pygame.Rect(power["x"] - 14, power["y"] - 14, 28, 28)
            
            if player_rect.colliderect(power_rect):
                if power["type"] == "speed":
                    self.speed_boost = True
                    self.speed_timer = POWERUP_DURATION
                    self.powerups_collected += 1
                elif power["type"] == "shield":
                    self.shield_active = True
                    self.shield_timer = POWERUP_DURATION
                    self.powerups_collected += 1
                else:
                    self.slow_motion_active = True
                    self.slow_motion_timer = POWERUP_DURATION
                    self.powerups_collected += 1
                self.powerups.remove(power)
                
    def update_enemies(self):
        player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)
        
        for enemy in self.enemies:
            enemy.update_ai(
                self.player_x, self.player_y,
                self.player_velocity_x, self.player_velocity_y,
                self.wall_manager.get_walls(),
                self.slow_motion_active,
                self.wall_manager.wall_grid
            )
            
            enemy_rect = pygame.Rect(enemy.x, enemy.y, enemy.size, enemy.size)
            
            if player_rect.colliderect(enemy_rect):
                if not self.shield_active:
                    damage = 2 if enemy.type in ["tank", "ambusher"] else 1
                    self.player_health -= damage
                    if self.player_health <= 0:
                        self.game_state = GAME_OVER
                    self.player_health = max(0, self.player_health)
                    
    def draw_game(self):
        # Walls
        self.wall_manager.draw(self.screen)
        
        # Powerups
        for power in self.powerups:
            colors = {"speed": ACCENT_YELLOW, "shield": ACCENT_PURPLE, "slowmotion": ACCENT_CYAN}
            color = colors.get(power["type"], TEXT_SECONDARY)
            pygame.draw.circle(self.screen, SURFACE, (power["x"], power["y"]), 16)
            pygame.draw.circle(self.screen, color, (power["x"], power["y"]), 14)
            pygame.draw.circle(self.screen, color, (power["x"], power["y"]), 14, 1)
            
        # Enemies
        for enemy in self.enemies:
            enemy_rect = pygame.Rect(enemy.x, enemy.y, enemy.size, enemy.size)
            enemy_color = enemy.get_color()
            
            # Shadow
            shadow_rect = enemy_rect.move(2, 2)
            pygame.draw.rect(self.screen, (0, 0, 0, 50), shadow_rect, border_radius=8)
            
            # Body
            pygame.draw.rect(self.screen, enemy_color, enemy_rect, border_radius=8)
            pygame.draw.rect(self.screen, BORDER, enemy_rect, 2, border_radius=8)
            
            # Label
            label_text = enemy.get_state_text()
            label_surface = self.font_tiny.render(label_text, True, ACCENT_RED)
            label_rect = label_surface.get_rect(center=(enemy.x + enemy.size // 2, enemy.y - 10))
            label_bg = pygame.Rect(label_rect.x - 4, label_rect.y - 2, label_rect.width + 8, label_rect.height + 4)
            pygame.draw.rect(self.screen, BG_PRIMARY, label_bg, border_radius=4)
            pygame.draw.rect(self.screen, ACCENT_RED, label_bg, 1, border_radius=4)
            self.screen.blit(label_surface, label_rect)
            
        # Player
        player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)
        player_color = ACCENT_CYAN if not self.shield_active else ACCENT_GREEN
        
        shadow_rect = player_rect.move(2, 2)
        pygame.draw.rect(self.screen, (0, 0, 0, 50), shadow_rect, border_radius=10)
        
        pygame.draw.rect(self.screen, player_color, player_rect, border_radius=10)
        pygame.draw.rect(self.screen, TEXT_PRIMARY, player_rect, 2, border_radius=10)
        
        if self.shield_active:
            shield_rect = player_rect.inflate(12, 12)
            pygame.draw.rect(self.screen, ACCENT_GREEN, shield_rect, 2, border_radius=12)
            
        self.update_floating_texts()
        self.update_health_particles()
        
    def draw_ui(self):
        # Top bar
        top_bar = pygame.Rect(0, 0, self.width, 80)
        self.draw_panel(top_bar, BG_SECONDARY, 0)
        
        # Score
        self.draw_text(f"SCORE: {int(self.score)}", self.font_small, TEXT_SECONDARY, 100, 25)
        total_score = int(self.score) + self.mission_score
        self.draw_text(f"TOTAL: {total_score}", self.font_small, TEXT_PRIMARY, 100, 50)
        
        # Level
        level_color = LEVEL_CONFIGS[self.current_level]["color"]
        self.draw_text(f"LEVEL {self.current_level}", self.font_medium, level_color, 
                      self.width // 2, 30)
        self.draw_text(LEVEL_CONFIGS[self.current_level]["name"], self.font_tiny, TEXT_SECONDARY,
                      self.width // 2, 55)
        
        # Health
        self.draw_text(f"HEALTH", self.font_tiny, TEXT_MUTED, self.width - 150, 20)
        health_rect = pygame.Rect(self.width - 200, 35, 180, 16)
        pygame.draw.rect(self.screen, TEXT_DARK, health_rect, border_radius=8)
        
        health_percent = self.player_health / self.player_max_health
        if health_percent > 0.6:
            health_color = HEALTH_HIGH
        elif health_percent > 0.3:
            health_color = HEALTH_MED
        else:
            health_color = HEALTH_LOW
            
        health_fill = pygame.Rect(self.width - 200, 35, int(180 * health_percent), 16)
        pygame.draw.rect(self.screen, health_color, health_fill, border_radius=8)
        self.draw_text(f"{self.player_health}/{self.player_max_health}", self.font_tiny, TEXT_PRIMARY,
                      self.width - 110, 55)
        
        # Mission panel
        mission_rect = pygame.Rect(12, self.height - 115, 190, 100)
        self.draw_panel(mission_rect)
        self.draw_text("MISSIONS", self.font_tiny, ACCENT_BLUE, 107, self.height - 105)
        
        y = self.height - 85
        for mission in self.missions.values():
            status = "✓" if mission["completed"] else "○"
            color = ACCENT_GREEN if mission["completed"] else TEXT_MUTED
            text = f"{status} {mission['desc']} ({mission['current']}/{mission['target']})"
            self.draw_text(text, self.font_tiny, color, 107, y)
            y += 22
            
        # Dash cooldown
        if self.dash_cooldown > 0:
            dash_text = f"DASH: {self.dash_cooldown // 60 + 1}s"
            self.draw_text(dash_text, self.font_tiny, ACCENT_BLUE, self.player_x + 25, self.player_y - 15)
            
    def run(self):
        while self.running:
            self.handle_events()
            
            self.screen.fill(BG_PRIMARY)
            self.draw_background_particles()
            self.draw_grid()
            
            if self.game_state == MENU:
                self.draw_text("SHAPE ESCAPE", self.font_title, TEXT_PRIMARY, self.width//2, self.height//2 - 120)
                self.draw_text("Expectimax AI", self.font_large, ACCENT_BLUE, self.width//2, self.height//2 - 60)
                
                info_y = self.height//2 + 40
                self.draw_text("Smooth AI movement with Expectimax algorithm", self.font_small, TEXT_SECONDARY,
                              self.width//2, info_y)
                self.draw_text("3 difficulty levels with increasing complexity", self.font_small, TEXT_SECONDARY,
                              self.width//2, info_y + 30)
                self.draw_text("+2 HP bonus every 100 points", self.font_small, ACCENT_GREEN,
                              self.width//2, info_y + 60)
                
                if self.draw_button("START GAME", self.width//2 - 120, self.height//2 + 130, 240, 50, ACCENT_BLUE):
                    self.reset_game()
                    self.game_state = PLAYING
                    
            elif self.game_state == PLAYING:
                self.handle_player_input()
                self.score += 0.35
                self.check_level_up()
                self.check_score_health_reward()
                self.update_enemies()
                self.update_powerups()
                
                self.draw_game()
                self.draw_ui()
                
            elif self.game_state == LEVEL_TRANSITION:
                self.handle_player_input()
                self.update_enemies()
                self.draw_game()
                self.draw_ui()
                
                overlay = pygame.Surface((self.width, self.height))
                overlay.set_alpha(180)
                overlay.fill(BG_PRIMARY)
                self.screen.blit(overlay, (0, 0))
                
                level_color = LEVEL_CONFIGS[self.current_level]["color"]
                self.draw_text(self.level_transition_message, self.font_large, level_color,
                              self.width//2, self.height//2 - 40)
                self.draw_text(LEVEL_CONFIGS[self.current_level]["description"], self.font_medium, TEXT_SECONDARY,
                              self.width//2, self.height//2 + 20)
                
                self.level_transition_timer -= 1
                if self.level_transition_timer <= 0:
                    self.game_state = PLAYING
                    
            elif self.game_state == GAME_OVER:
                overlay = pygame.Surface((self.width, self.height))
                overlay.set_alpha(200)
                overlay.fill(BG_PRIMARY)
                self.screen.blit(overlay, (0, 0))
                
                self.draw_text("GAME OVER", self.font_title, ACCENT_RED, self.width//2, self.height//2 - 100)
                self.draw_text(f"FINAL SCORE: {int(self.score)}", self.font_medium, TEXT_PRIMARY,
                              self.width//2, self.height//2 - 20)
                self.draw_text(f"TOTAL SCORE: {int(self.score) + self.mission_score}", self.font_small, ACCENT_BLUE,
                              self.width//2, self.height//2 + 20)
                self.draw_text(f"LEVEL REACHED: {self.current_level}", self.font_small, TEXT_SECONDARY,
                              self.width//2, self.height//2 + 60)
                
                if self.draw_button("PLAY AGAIN", self.width//2 - 100, self.height//2 + 130, 200, 45, ACCENT_BLUE):
                    self.reset_game()
                    self.game_state = PLAYING
                    
            pygame.display.update()
            self.clock.tick(FPS)
            
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    game = ShapeEscapeGame()
    game.run()